﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System;



public class UIRichText : MonoBehaviour {
    RectTransform selfRectTransform;

    float width = 0f;
    float height = 0f;
    float caculaterW = 0f;
    float caculaterH = 0f;
    float maxRowHeight = 0f;

    GameObject TextFont = null;
    GameObject ImageAsset = null;
    GameObject imgObj = null;
    void Awake()
    {
        imgObj = Resources.Load<GameObject>("Img/img");
        TextFont = Resources.Load<GameObject>("TextAssets"); ;
        selfRectTransform = transform.GetComponent<RectTransform>();
        ImageAsset = Resources.Load<GameObject>("ImgAssets"); ;

        width = selfRectTransform.rect.width - 20f;
        height = selfRectTransform.rect.height;

    }
	// Use this for initialization
    void Start () {

//         for(int i = 0; i < 10;i++)
//         {
//             GameObject text = GameObject.Instantiate(TextFont);
//             Text t1 = text.GetComponent<Text>();
//             t1.text = "汉字abc";
//             t1.GetComponent<RectTransform>().sizeDelta = new Vector2(t1.preferredWidth, t1.preferredHeight);
//             setContent(t1.gameObject);
//         }
// 
//         GameObject img = GameObject.Instantiate(ImageAsset);
//         img.GetComponent<Image>().sprite = sprite;
//         setContent(img.gameObject);
// 
//         for (int i = 0; i < 10; i++)
//         {
//             GameObject text = GameObject.Instantiate(TextFont);
//             Text t1 = text.GetComponent<Text>();
//             t1.text = "汉字abc";
//             t1.GetComponent<RectTransform>().sizeDelta = new Vector2(t1.preferredWidth, t1.preferredHeight);
//             setContent(t1.gameObject);
//         }
//         img = GameObject.Instantiate(ImageAsset);
//         img.GetComponent<Image>().sprite = sprite;
//         setContent(img.gameObject);

//        string str = "fdsfdsfdsfddsd汉字sfdfdas<img>aaa</img>fdsfd汉字sfdsfddsdsfdfdas<img>aaa</img>fdsfdsf汉字dsfddsdsfdfdas<img>aaa</img>fdsfds汉字fdsfddsdsfdfdas<img>aaa</img>fdsfdsf汉字dsfddsdsfdfdas<img>aaa</img>fdsfdsfdsfddsdsfdfdas<img>aaa</img>fdsfdsfdsfddsdsfdfdas<img>aaa</img>";
//        setString(str);
    }


    enum ContentType
    {
        eText = 0,
        eImage,
    }

   public void setString(string content)
    {
        caculaterW = 0;
        Regex regExp = new Regex(@"(?is)(?<=<img[^>]*>).*?(?=</img>)");
        Queue<string> imgName = new Queue<string>();
        MatchCollection mc = regExp.Matches(content);
        foreach (Match m in mc)
        {
            Debug.Log(m.Value);//这个
            imgName.Enqueue(m.Value);
        }
        string strOutput = "";
        
        regExp = new Regex(@"(?is)(?<=<img[^>]*>).*?(?=</img>)");
        strOutput = regExp.Replace(content, "");
        strOutput = Regex.Replace(strOutput, @"</?img[^>]*>", "/t");
        Debug.Log(strOutput);

        //         int idx = 0;
        //         while(strOutput.IndexOf("/t/t", idx) != -1)
//         {
//             Debug.Log("pos => " + strOutput.IndexOf("/t/t", idx));
//            idx++;
//         }

        string[] contents = strOutput.Split(new string[] { "/t/t" }, StringSplitOptions.None);
        foreach (string st in contents)
        {
            if(string.IsNullOrEmpty(st))
            {
                if(imgName.Count !=0)
                    setContent(imgName.Dequeue(), ContentType.eImage);
            }
            else
            {
                setContent(st, ContentType.eText);
                if (imgName.Count != 0)
                    setContent(imgName.Dequeue(), ContentType.eImage);
            }
        }
    }

    GameObject CreateText()
    {
        
        GameObject text = GameObject.Instantiate(TextFont);
        text.GetComponent<RectTransform>().sizeDelta = new Vector2(0f, 0f);
        text.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
        text.transform.SetParent(transform);
        return text;
    }
	


    GameObject CreateImg(string name)
    {
        GameObject img = GameObject.Instantiate(ImageAsset);
        if (name == "gif")
        {
            img.AddComponent<UniGifTest>();
            UniGifTexture uniGifTexture = img.AddComponent<UniGifTexture>();
            uniGifTexture.loadOnStart = true;
            uniGifTexture.loadOnStartUrl = "gif.gif";
            img.transform.SetParent(transform);
        }
        else
        {
            Transform imgSprite = imgObj.transform.FindChild(name);
            img.GetComponent<Image>().sprite = imgSprite.GetComponent<SpriteRenderer>().sprite;
            img.transform.SetParent(transform);
        }
        img.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
        return img;
    }

    void setContent(string content, ContentType type)
    {
        
        GameObject textTmp = null;
        switch(type)
        {
            case ContentType.eText:
                {
                    Debug.Log("content==>" + content);
                    textTmp = CreateText();
                    textTmp.transform.localPosition = new Vector3(caculaterW, -caculaterH);
                    for (int i = 0; i < content.Length;i++)
                    {
                        if (caculaterW >= width)
                        {
                            caculaterW = 0f;
                            caculaterH += 30f;
                            textTmp = CreateText();
                            Text text = textTmp.GetComponent<Text>();
                            float preW = text.GetComponent<RectTransform>().rect.width;
                            text.text += content[i].ToString();
                            text.GetComponent<RectTransform>().sizeDelta = new Vector2(text.preferredWidth, 30);
                            textTmp.transform.localPosition = new Vector3(caculaterW, -caculaterH);
                            caculaterW += text.GetComponent<RectTransform>().rect.width - preW;
                        }
                        else
                        {                                                       
                            Text text = textTmp.GetComponent<Text>();
                            float preW = text.GetComponent<RectTransform>().rect.width;
                            text.text += content[i].ToString();                            
                            text.GetComponent<RectTransform>().sizeDelta = new Vector2(text.preferredWidth, 30);                            
                            caculaterW += text.GetComponent<RectTransform>().rect.width - preW;

                        }
                        
                    }
                    transform.GetComponent<RectTransform>().sizeDelta = new Vector2(width + 15f, caculaterH + 30f);
                    break;
                }
            case ContentType.eImage:
                {
                    GameObject image = CreateImg(content);
                   
                    if (caculaterW + image.GetComponent<RectTransform>().rect.width > width)
                    {
                        caculaterH += 30f;
                        caculaterW = 0f;
                    }
                    image.transform.localPosition = new Vector3(caculaterW, -caculaterH);
                    caculaterW += image.GetComponent<RectTransform>().rect.width;
                    transform.GetComponent<RectTransform>().sizeDelta = new Vector2(width + 15f, caculaterH + 30f);
                    break;
                }
            default:
                break;
        }
         
    }
    
}


