﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class test : MonoBehaviour {
    public InputField inputField;
    public GameObject richTextObj;
    public GameObject content;
    float height = 0f;
    float initHeight = 0f;
	// Use this for initialization
	void Start () {
        initHeight = content.GetComponent<RectTransform>().rect.height;

    }
	
	public void onClicked()
    {
        string str = inputField.text;
        str = str.Trim();
        if (string.IsNullOrEmpty(str))
        {
            Debug.Log("str empty!");
            return;
        }
        GameObject richtext = GameObject.Instantiate(richTextObj);
        richtext.GetComponent<UIRichText>().setString(str);
        richtext.transform.SetParent(content.transform);
        richtext.transform.localPosition = new Vector3(0, -height);
        height += richtext.transform.GetComponent<RectTransform>().rect.height;
        if(initHeight< height)
        {
            content.transform.GetComponent<RectTransform>().sizeDelta = new Vector2(content.transform.GetComponent<RectTransform>().rect.width, height);
        }
        inputField.text = "";
    }
}
